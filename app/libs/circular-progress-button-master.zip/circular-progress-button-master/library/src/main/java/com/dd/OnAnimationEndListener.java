package com.dd;

interface OnAnimationEndListener {

    public void onAnimationEnd();
}
